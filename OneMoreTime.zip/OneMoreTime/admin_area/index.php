<!-- connect file-->
<?php
include('../includes/connect.php');
include('../functions/common_function.php');
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Dashboard</title>
   <!-- css file -->
   <link rel="stylesheet" href="../style.css">
  <!--bootstrap css link -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 <style>
    .admin_image{
    width:100px;
    object-fit:contain;
    }
    .footer{
        position:absolute;
        bottom:0;
    }
    body{
        overflow-x:hidden;
    }
    .product_img{
        width:100px;
        object-fit:contain;
    }
    label{
        overflow-y:hidden;
    }
    h1{
        overflow-y:hidden;
    }
 </style>
 <!-- font awesome link-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<!--navbar-->
<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-success"> 
        <div class="container-fluid"> 
            <img src= "../img/logo.png" alt="" class="logo">
            <nav class="navbar navbar-expand-lg"> 
                <ul class="navbar-nav">
                   <!-- <li class="nav-item">
                      <a href= "" class="nav-link"> Welcome guest</a>  
                    </li> -->   
                    <?php
                    if(isset($_SESSION['username'])){
  echo "<li class='nav-item'>
  <a class='nav-link' href='index.php'>Welcome ".$_SESSION['username']." </a>
</li>";
                    }
?>
                

                 </ul>
            </nav>
        </div>
    </nav>
    <!--second child -->
    <div class="bg-light">
        <h3 class="text-center p-2"> Manage Details</h3>
    </div>
    <!--third child-->
    <div class="row">
        <div class="col-md-12 bg-secondary p-1 d-flex align-items-center">
            <div class="p-5">
                <a href="http://localhost/chatmod/ChatApp/ChatApp-/login.php"><img src="../img/admin.png" alt ="" class="admin_image"></a>
                <p class="text-light text-center">Admin</p>
                
            </div>
            <div class="button text-center"> 
                <button class="my-3"> <a href="insert_product.php" class="nav-link text-light bg-success my-1">Insert Products</a></button>
                <button> <a href="index.php?view_products" class="nav-link text-light bg-success my-1">View Products</a></button>
                <button> <a href="index.php?insert_category" class="nav-link text-light bg-success my-1">Insert Category</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1">View Category</a></button>
                <button> <a href="index.php?insert_service" class="nav-link text-light bg-success my-1">Insert Services</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1">View Services</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1">All Orders</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1"> All Payments</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1">List Users</a></button>
                <button> <a href="" class="nav-link text-light bg-success my-1">Logout</a></button>
            </div>
        </div>
    </div>
    <!-- fourth child-->
    <div class= "insertcontainer my-3">
        <?php
        if(isset($_GET['insert_category'])){
            include('insert_category.php');
        }
        if(isset($_GET['insert_service'])){
            include('insert_services.php');
        }
        if(isset($_GET['view_products'])){
            include('view_products.php');
        }
        if(isset($_GET['edit_products'])){
            include('edit_products.php');
        }
        if(isset($_GET['delete_products'])){
            include('delete_products.php');
        }
        ?>
    </div>

    <!-- last child
<div class="bg-success p-3 text-center footer">
<p> All rights reserved &copy; Designed by One More Time 2023</p>
</div> -->


<?php
include('../includes/footer.php');
?>
</div>



<!--bootstrap js link-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>