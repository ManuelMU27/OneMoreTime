<?php
include('../includes/connect.php');

if(isset($_POST['insert_cat'])){
    $category_title = mysqli_real_escape_string($con, $_POST['cat_title']);

    // Select data from db
    $select_query = "SELECT * FROM category WHERE category_title = '$category_title'";
    $result_select = mysqli_query($con, $select_query);
    $number = mysqli_num_rows($result_select);

    if($number > 0){
        echo "<script> alert('This category is already present in the database')</script>";
    } else {
        $insert_query = "INSERT INTO category (category_title) VALUES ('$category_title')";
        $result = mysqli_query($con, $insert_query);
        
        if($result){
            echo "<script> alert('Category has been inserted successfully')</script>";
        }
    }
}
?>
<h2 class="text-center">INSERT CATEGORIES</h2>


<form action="" method="post" class="mb-2">
<div class="input-group w-90 mb-2">
  <span class="input-group-text bg-success" id="basic-addon1"><i class="fa-solid fa-receipt"></i> </span>
  <input type="text" class="form-control" name="cat_title" placeholder="Insert category" aria-label="Category" aria-describedby="basic-addon1">
</div>
<div class="input-group w-10 mb-2 m-auto">
  <input type="submit" class=" bg-success border-0 p-2 my-3" name="insert_cat" value="Insert category">
</div>
<!--cancel button-->
<div class="form-outline mb-4 w-50 m-auto">
        <a href="index.php" class="btn btn-secondary mb-3 px-3">Cancel</a> 
        </div>

</form>