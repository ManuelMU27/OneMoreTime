<?php
include('../includes/connect.php');

if(isset($_POST['insert_service'])){
    $service_title = mysqli_real_escape_string($con, $_POST['service_title']);

    // Select data from db
    $select_query = "SELECT * FROM service WHERE service_title = '$service_title'";
    $result_select = mysqli_query($con, $select_query);
    $number = mysqli_num_rows($result_select);

    if($number > 0){
        echo "<script> alert('This Service is already present in the database')</script>";
    } else {
        $insert_query = "INSERT INTO service (service_title) VALUES ('$service_title')";
        $result = mysqli_query($con, $insert_query);
        
        if($result){
            echo "<script> alert('Service has been inserted successfully')</script>";
        }
    }
}
?>
<h2 class="text-center">INSERT SERVICES</h2>



<form action="" method="post" class="mb-2">
<div class="input-group w-90 mb-2">
  <span class="input-group-text bg-success" id="basic-addon1"><i class="fa-solid fa-receipt"></i> </span>
  <input type="text" class="form-control" name="service_title" placeholder="Insert services" aria-label="Services" aria-describedby="basic-addon1">
</div>
<div class="input-group w-10 mb-2 m-auto">
  
  <input type="submit" class=" bg-success border-0 p-2 my-3" name="insert_service" value="Insert Services">
  
</div>
<!--cancel button-->
<div class="form-outline mb-4 w-50 m-auto">
        <a href="index.php" class="btn btn-secondary mb-3 px-3">Cancel</a> 
        </div>
</form>