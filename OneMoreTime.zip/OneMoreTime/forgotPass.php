<!DOCTYPE html>
<html lang = "en">
<head>
  <meta charset = "UTF-8">
  <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
  <meta http-eqquiv = "X-UA-Compatible" content = "ie = edge">
  <title>Forgot Password Form</title>
  <link rel = "stylesheet" href = "style.css">  
</head>
<body>
  <div class = "container">
    <input type = "checkbox" id = "check">
    <div class = "Email form">
      <header>Forgot password?</header>
      <form action = "#">
        <input type = "text" placeholder = "Enter your email">
        <a href = "#">Send code</a>
        <input type = "button" value = "Submit">
      </form>
    </div>
  </div>
</body>
</html>
