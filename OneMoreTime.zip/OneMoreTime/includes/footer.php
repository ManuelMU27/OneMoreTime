<div class="bg-success p-3 text-center">
<p> All rights reserved &copy; Designed by One More Time 2023</p>
</div>