<!DOCTYPE html>
<html lang = "en">
<head>
  <meta charset = "UTF-8">
  <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
  <meta http-eqquiv = "X-UA-Compatible" content = "ie = edge">
  <title>Registration Form</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class = "container">
    <input type="checkbox" id="check">
    <div class="signup form">
      <header>Register</header>
      <form id="registrationForm" action="/register" method="POST">
        <input type="text" name="email" placeholder="Enter your email">
        <input type="password" name="password" placeholder="Create a password">
        <input type="password" placeholder="Confirm your password">
        <input type="submit" class="button" value="Signup">
      </form>
  </div>
  </div>
  <script src="script.js"></script>
</body>
</html>