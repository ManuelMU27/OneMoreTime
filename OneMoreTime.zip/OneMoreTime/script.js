document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('.login form');
    const registrationForm = document.querySelector('.registration form');
    const signupLabel = document.querySelector('.signup label');
    const check = document.getElementById('check');

    // Show the registration form when the "Signup" label is clicked
    signupLabel.addEventListener('click', function () {
        if (check.checked) {
            registrationForm.style.display = 'block';
            loginForm.style.display = 'none';
        }
    });

    // Show the login form when the "Login" label is clicked
    check.addEventListener('change', function () {
        if (this.checked) {
            loginForm.style.display = 'block';
            registrationForm.style.display = 'none';
        }
    });
    
    // Handle form submissions (you can add your logic here)
    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const email = loginForm.querySelector('input[type="text"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;
        // Implement login logic here
        console.log(`Login with email: ${email}`);
    });

    registrationForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const email = registrationForm.querySelector('input[type="text"]').value;
        const password = registrationForm.querySelector('input[type="password"]').value;
        // Implement registration logic here
        console.log(`Registered with email: ${email}`);
    });
});

//Forgot password (shouldn't we make another page for this so it directs to another page whichnis only for 'Forgot password'? Just saying  idk lol).

function ShowForgotPasswordForm() {
  SetTitle("Forgot Password");
  ShowHideForm("RegistrationFrom", "Hide");
  ShowHideForm("LoginForm", "Hide");
  ShowHideForm("ForgotPasswordForm", "Show");

  ActiveInactiveBtn('ShowLoginBtn', "Active");
  ActiveInactiveBtn('ShowRegistrationBtn', "Inactive");
}

function ActiveInactiveBtn(ButtonId, ActiveORInactive){

  var Button = document.getElementById(ButtonId);
  if(ActiveORInactive == "Active"){
    Button.classList.add("active");
  } else {
    Button.classList.remove("active");
  }
}


loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const email = loginForm.querySelector('input[type="text"]').value;
    const password = loginForm.querySelector('input[type="password"]').value;

    // Send the login data to the server for verification
    fetch('/login-endpoint', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to the homepage on successful login
            window.location.href = '/homepage.html';
        } else {
            // Handle login failure (show error message, etc.)
            console.log('Login failed. Please check your credentials.');
        }
    })
    .catch(error => {
        console.error('An error occurred:', error);
    });
});
